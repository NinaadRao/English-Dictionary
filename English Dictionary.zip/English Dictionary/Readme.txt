=========================================================ENGLISH DICTIONARY===================================================================

1.Put the whole folder in your system.
2.Make sure you have pandas,codecs,nltk,flask and itertools installed in your system(for python).
3.After installation of the required packages is done, run the program.
4.Type the server address in the web browser and your english dictionary is good to go.
5.If there is no word found, it will display word/meaning not found.
