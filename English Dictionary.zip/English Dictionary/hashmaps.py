import os
import time
starttime=time.time()
from os import listdir
from os.path import isfile, join
import pandas as pd
import codecs
from nltk.stem import PorterStemmer
ps=PorterStemmer()
from nltk.stem import WordNetLemmatizer
lemmatizer=WordNetLemmatizer()
from flask import Flask, request, render_template
app = Flask(__name__)
from itertools import chain
from nltk.corpus import wordnet
dictionarypath='modified data set ds/'
wordpath='Word lists in csv/'

filedictionary = [f for f in listdir(dictionarypath) if isfile(join(dictionarypath, f))]
fileword= [f for f in listdir(wordpath) if isfile(join(wordpath, f))]
filedictionary.sort()
fileword.sort()
letterdictionary={}
fullword=[]
alpha='abcdefghijklmnopqrstuvwxyz'.upper()
pos1=[]
triedictionary={}
#mean=[]

def dictionary():
    '''
    this function is used to remove all the duplicate words and store it in a 
    list which is stored in a worddictionary of type {'A':{all the words from a}}'''
    worddictionary={}
    count=0
    secondcount=0
    for file in fileword:
        f=codecs.open(wordpath+file,'r',encoding='utf-8',errors='ignore')
        words=[]
        for i in f:
            secondcount+=1
            if i[0:-2].strip(" ") not in words:
                words.append(i[0:-2].strip(" "))
                count+=1
        worddictionary[file[0]]=words
    
    
    print("Total number of words:",secondcount,"\nWords without duplicates:",count)
    
    return worddictionary

#To check how many words are present, uncomment the next line
#dictionary()
    
def letterdict(alpha,letterdictionary):
    '''It returns a hashmap with each key as the english alphabet and the
    corresponding values as a dictionary(It is just initialized over here). eg
    letterdictionary={'A':{},'B':{}...}'''
    for i in alpha:
        letterdictionary[i]=dict()
    return letterdictionary

letterdictioanary=letterdict(alpha,letterdictionary)




def hashwordletter(letterdictionary):
    '''It completes the letterdictionary and now its values are for eg: 
        letterdictionary={'A':{'a':{'():[The first letter of the English and of many other alphabets.'],(n.):
            ['some meaning1','some meaning 2']}}}'''
    
    for file in filedictionary:
        with codecs.open(dictionarypath+file,'r',encoding='utf-8',errors='ignore') as f:
            reader=pd.read_csv(f)
           
            for i in range(len(reader)):
                meaning=[]
                read=str(reader["words"][i]).rstrip()
                if (read in letterdictioanary[file[0]]):
                    if reader["pos"][i] in letterdictionary[file[0]][read]:
                        letterdictionary[file[0]][(read)][reader["pos"][i]].append(reader["meaning"][i])
                    else:
                        letterdictionary[file[0]][(read)][reader["pos"][i]]=[reader["meaning"][i]]
                else:
                    pos={}
                    meaning.append(reader["meaning"][i])
                    pos[reader["pos"][i]]=meaning
                    letterdictionary[file[0]][read]=dict(pos)
    return letterdictionary
 


              
def allwords(fullword,startletter):
    '''It returns all the words starting from the word entered by the user which
    can be used for printing the line number(where the word is found in the csv file)
    and building the Trie data structure'''
    with codecs.open(dictionarypath+startletter+".csv",'r',encoding='utf-8',errors='ignore') as f:
        reader=pd.read_csv(f)
        fullword=list(reader["words"])
        fullword=[(str(i)).rstrip() for i in fullword]
        return fullword
    
             
def printlinenumber(word, fullword, startletter):
    
    '''printing the line number(where the word is found in the csv file)'''
    if(word in fullword):
        return "File name:"+startletter+".csv "+" Line number:"+str(fullword.index(word)+2)
        
    else:
        return None
             

            
             
    
#Trie              
class Node():
    def __init__(self,label=None,data=None,mean=None,pos=None):
        self.label = label
        self.data = data
        self.mean = mean
        self.children = dict()
        
    def addChild(self,key,data=None,mean=None):
        if not isinstance(key,Node):
            self.children[key]  = Node(key,data,mean)
        else:
            self.children[key.label]= key
            
    def __getitem__(self,key):
        return self.children[key]

class Trie:
    def __init__(self):
        self.head = Node()
    
    def __getitem__(self,key):
        return self.head.children[key]
    
    def addchild(self,word,mean):
        current_node = self.head
        word_finished = True
        
        for i in range(len(word)):
            if(word[i] in current_node.children):
                current_node = current_node.children[word[i]]
            else:
                word_finished = False
                break
                
        if not word_finished:
            while i < len(word):
                current_node.addChild(word[i])
                current_node = current_node.children[word[i]]
                i += 1
        current_node.data = word
        current_node.mean = mean
        
    def has_word(self, word):
        current_node = self.head
        flag = True
        for letter in word:
            if letter in current_node.children:
                current_node = current_node.children[letter]
            else:
                flag = False
                break
        if flag:
            if current_node.data == None:
                flag = False
        
        return flag
    def getmeaning(self,word):
        if not self.has_word(word):
            return
        
        current_node = self.head
        for letter in word:
            current_node = current_node[letter]
        return current_node.mean

       
                  
             
letterdictionary=hashwordletter(letterdictionary)             
#Building the Trie data structure for every word
for letters in alpha:
    lasttime=time.time()
    print("letter now is ",letters)
    wordfull=[]
    triedictionary[letters.upper()]=Trie()
    wordfull=allwords(wordfull,letters.upper())
    for full in wordfull:
        triedictionary[letters.upper()].addchild(full,letterdictionary[letters.upper()][full])
    #print(time.time()-lasttime)         
             
             
             
             
print("The total time taken for Tries and the required hashmap to constructed is",time.time()-starttime)


startletter=''
choice=1
previous=''
t=Trie()
word=" "
def synonym(word,triedictionary):
    synonyms = wordnet.synsets(word)
    lemmas = set(chain.from_iterable([word.lemma_names() for word in synonyms]))
    l=[ps.stem(i) for i in lemmas]
    l=set(l)
    m=[]
    for i in l:
        stri=i
        stri=list(stri)
        
        if ('_' in i):
            stri[stri.index('_')]=' '
        if('-'  in i):
            stri[stri.index('-')]=''
        stri=''.join(stri)
        
        synflag=0
        for j in stri:
            if(j.isdigit==0):
                synflag==1
                break
        if synflag==1:
            if(triedictionary[stri[0].upper()].has_word(stri)):
                m.append(stri)
    return m
    
  


co=0
@app.route('/')
def d():
    return render_template('dictionary.html')

@app.route("/dic", methods=['POST'])
def start():
    word=request.form['w']
    print(word)
    if(word):
        
        lasttime=time.time()
        
        startletter=word[0].upper()
        
        word=word.lower()
        
        flag=0
        for i in word:
            if i.isdigit()==True:
                flag=1
                break
        if flag==0:
            if(triedictionary[startletter].has_word(word)==False):
                if(triedictionary[startletter].has_word(ps.stem(word))==False):
                    fullword=allwords([],startletter)
                    return render_template('dictionary.html',w=None,fw=None,sl=None,m=None,t=None,c=1,line=printlinenumber(ps.stem(word), fullword, startletter))
                else:
                    mean=triedictionary[startletter].getmeaning(ps.stem(word))
                    word=ps.stem(word)
                    flag=1
                    fullword=allwords([],startletter)
                    synonyms=synonym(word,triedictionary)
                    return render_template('dictionary.html',c=1,w=word,fw=fullword,sl=startletter,m=mean,t=(time.time()-lasttime),s=synonyms,line=printlinenumber(word, fullword, startletter))    
            else:
                fullwor=allwords([],startletter)
                mean=triedictionary[startletter].getmeaning(word)
                print(word)
                synonyms=synonym(word,triedictionary)
                return render_template('dictionary.html',w=word,s=synonyms,fw=fullwor,sl=startletter,m=mean,t=(time.time()-lasttime),c=1,line=printlinenumber(word, fullwor, startletter))
        else:
            return render_template('dictionary.html',c=1,w=None,fw=None,sl=None,m=None,t=None,line=None)
    else:
        return render_template('dictionary.html',c=0,w=None,fw=None,sl=None,m=None,t=None,line=None)
app.run(debug=True)        
            

#print(lemmatizer.lemmatize("better",pos="r"))
#print(lemmatizer.lemmatize("running",'v'))
 

